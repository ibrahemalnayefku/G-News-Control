#!/system/bin/sh

if [ "$1" = "switch" ]; then
  su -c sh /data/adb/modules/gnewscontrol/action.sh
else
  echo "G-News Control"
  echo "To toggle the news feed state, type here: gnc switch"
fi
