#!/system/bin/sh

sleep 10

COMPONENT_FULL="com.google.android.googlequicksearchbox/com.google.android.apps.gsa.nowoverlayservice.DrawerOverlayService"
PROP_NAME="persist.sys.gnc.enable_feed"

LOG_TAG="GNC_Module"

FEED_ENABLED=$(getprop "$PROP_NAME")

if [ "$FEED_ENABLED" = "1" ]; then
  pm enable --user 0 "$COMPONENT_FULL"
  log -p i -t "$LOG_TAG" "Prop is '1'. Enabling component on boot."
else
  pm disable --user 0 "$COMPONENT_FULL"
  log -p i -t "$LOG_TAG" "Prop is '0'. Disabling component on boot."
fi

exit 0

