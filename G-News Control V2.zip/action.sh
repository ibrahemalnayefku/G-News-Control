#!/system/bin/sh

PKG="com.google.android.googlequicksearchbox"
COMPONENT_FULL="$PKG/com.google.android.apps.gsa.nowoverlayservice.DrawerOverlayService"
USER="0"
STATE_FILE="/data/adb/modules/gnewscontrol/state.txt"

if [ "$(id -u 2>/dev/null)" != "0" ]; then
  if command -v su >/dev/null 2>&1; then
    exec su -c "sh '$0' '$@'"
  else
    echo " ♯ ROOT access not detected."
    exit 1
  fi
fi

apply_dpi_trick() {
  echo " ⚙ Partial launcher update..."

  CURRENT_DENSITY=$(wm density | grep "Override density" | grep -oE '[0-9]+')

  if [ -z "$CURRENT_DENSITY" ]; then
    CURRENT_DENSITY=$(wm density | grep "Physical density" | grep -oE '[0-9]+')
  fi

  if [ -n "$CURRENT_DENSITY" ]; then
    (
      wm density $((CURRENT_DENSITY + 1))
      sleep 0.2
      wm density "$CURRENT_DENSITY"
    ) &
  else
    echo " ! Update error. It is likely a reboot will be required to apply the changes."
  fi
}

CURRENT_STATE=$(cat "$STATE_FILE" 2>/dev/null)

if [ "$CURRENT_STATE" = "on" ]; then
  echo " 𒊹 Current state: ON"
  echo " ❍ Disabling..."
  pm disable --user "$USER" "$COMPONENT_FULL" >/dev/null 2>&1

  # Write new state "OFF" to file
  echo "off" > "$STATE_FILE"

  echo " ◯ New state: OFF"
  exit 0
else
  echo " ◯ Current state: OFF"
  echo " ❍ Enabling..."
  pm enable --user "$USER" "$COMPONENT_FULL" >/dev/null 2>&1

  echo "on" > "$STATE_FILE"

  apply_dpi_trick

  echo " 𒊹 New state: ON"
  exit 0
fi
