#!/system/bin/sh

COMPONENT_FULL="com.google.android.googlequicksearchbox/com.google.android.apps.gsa.nowoverlayservice.DrawerOverlayService"
STATE_FILE="$MODPATH/state.txt"

echo "off" > "$STATE_FILE"

pm disable --user 0 "$COMPONENT_FULL" >/dev/null 2>&1



OLD_MODULE_ID="byleftgoogle"
OLD_MODULE_DIR="/data/adb/modules/$OLD_MODULE_ID"

mkdir -p $MODPATH/system/bin
cp -f $TMPDIR/gnc.sh $MODPATH/system/bin/gnc
set_perm $MODPATH/system/bin/gnc 0 0 0755
echo ""
echo ""
echo "  ••••••••••  INFORMATION  ••••••••••  "
echo ""
echo ""
if [ -d "$OLD_MODULE_DIR" ]; then
  echo " ⌕ Detected an older version — «ByeLeftGoogle»."
  rm -rf "$OLD_MODULE_DIR"
  echo " ⌦ The old version has been removed."
  echo ""
fi
echo " ↺ After reboot, control will be available via the >_SCRIPT button,"
echo "as well as through the terminal commands:
    gnc — check current state 
    gnc switch — change state"
echo ""
echo " ↓ G-News Control is installed. The news feed is already disabled."
exit 0
