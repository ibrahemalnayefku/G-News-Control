#!/system/bin/sh

COMPONENT_FULL="com.google.android.googlequicksearchbox/com.google.android.apps.gsa.nowoverlayservice.DrawerOverlayService"
STATE_FILE="/data/adb/modules/gnewscontrol/state.txt""
MODULE_DIR="/data/adb/modules/gnewscontrol"

apply_dpi_trick() {
  CURRENT_DENSITY=$(wm density | grep "Override density" | grep -oE '[0-9]+')

  if [ -z "$CURRENT_DENSITY" ]; then
    CURRENT_DENSITY=$(wm density | grep "Physical density" | grep -oE '[0-9]+')
  fi

  if [ -n "$CURRENT_DENSITY" ]; then
    (
      wm density $((CURRENT_DENSITY + 1))
      sleep 0.2
      wm density "$CURRENT_DENSITY"
    ) &
  fi
}

echo "Restoring to original state..."
pm enable --user 0 "$COMPONENT_FULL" >/dev/null 2>&1
apply_dpi_trick

if [ -f "$STATE_FILE" ]; then
    rm -f "$STATE_FILE"
fi

rm -rf "$MODULE_DIR"

exit 0
