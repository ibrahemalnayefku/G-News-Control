#!/system/bin/sh

PKG="com.google.android.googlequicksearchbox"
COMPONENT_FULL="$PKG/com.google.android.apps.gsa.nowoverlayservice.DrawerOverlayService"
USER="0"
STATE_FILE="/data/adb/modules/gnewscontrol/state.txt"

if [ "$(id -u 2>/dev/null)" != "0" ]; then
  if command -v su >/dev/null 2>&1; then
    exec su -c "sh '$0' '$@'"
  else
    echo " ♯ Не удалось обнаружить ROOT права."
    exit 1
  fi
fi

apply_dpi_trick() {
  echo " ⚙ Частичное обновление лаунчера..."

  CURRENT_DENSITY=$(wm density | grep "Override density" | grep -oE '[0-9]+')

  if [ -z "$CURRENT_DENSITY" ]; then
    CURRENT_DENSITY=$(wm density | grep "Physical density" | grep -oE '[0-9]+')
  fi

  if [ -n "$CURRENT_DENSITY" ]; then
    (
      wm density $((CURRENT_DENSITY + 1))
      sleep 0.2
      wm density "$CURRENT_DENSITY"
    ) &
  else
    echo " ! Ошибка обновления. Вероятно для применения изпенений нужно будет перезагрузить устройство."
  fi
}

CURRENT_STATE=$(cat "$STATE_FILE" 2>/dev/null)

if [ "$CURRENT_STATE" = "on" ]; then
  echo " 𒊹 Текущее состояние: ВКЛ"
  echo " ❍ Отключение..."
  pm disable --user "$USER" "$COMPONENT_FULL" >/dev/null 2>&1

  # Записываем новое состояние "ВЫКЛ" в файл
  echo "off" > "$STATE_FILE"

  echo " ◯ Новое состояние: ВЫКЛ"
  exit 0
else
  echo " ◯ Текущее состояние: ВЫКЛ"
  echo " ❍ Включение..."
  pm enable --user "$USER" "$COMPONENT_FULL" >/dev/null 2>&1

  echo "on" > "$STATE_FILE"

  apply_dpi_trick

  echo " 𒊹 Новое состояние: ВКЛ"
  exit 0
fi
