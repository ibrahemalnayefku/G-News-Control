#!/system/bin/sh

COMPONENT_FULL="com.google.android.googlequicksearchbox/com.google.android.apps.gsa.nowoverlayservice.DrawerOverlayService"
STATE_FILE="$MODPATH/state.txt"

echo "off" > "$STATE_FILE"

pm disable --user 0 "$COMPONENT_FULL" >/dev/null 2>&1



OLD_MODULE_ID="byleftgoogle"
OLD_MODULE_DIR="/data/adb/modules/$OLD_MODULE_ID"

mkdir -p $MODPATH/system/bin
cp -f $TMPDIR/gnc.sh $MODPATH/system/bin/gnc
set_perm $MODPATH/system/bin/gnc 0 0 0755
echo ""
echo ""
echo "  ••••••••••  ИНФОРМАЦИЯ  ••••••••••  "
echo ""
echo ""
if [ -d "$OLD_MODULE_DIR" ]; then
  echo " ⌕ Обнаружена ранняя версия — «ByeLeftGoogle»."
  rm -rf "$OLD_MODULE_DIR"
  echo " ⌦ Ранняя версия удалена."
  echo ""
fi
echo " ↺ После перезагрузки станет доступно управление через >_СКРИПТ,"
echo "а так же через терминал, команды:
    gnc — узнать текущее состояние 
    gnc switch — сменить состояние"
echo ""
echo " ↓ G-News Control установлен. Лента новостей уже отключена."
exit 0
