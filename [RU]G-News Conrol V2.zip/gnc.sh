#!/system/bin/sh

if [ "$1" = "switch" ]; then
  su -c sh /data/adb/modules/gnewscontrol/action.sh
else
  echo "G-News Control"
  echo "Для переключения состояния ленты новостей отправьте здесь: gnc switch"
fi
