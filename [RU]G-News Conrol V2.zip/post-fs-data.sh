#!/system/bin/sh

STATE_FILE="/data/adb/modules/gnewscontrol/state.txt"
PROP_NAME="persist.sys.gnc.enable_feed"

if [ -f "$STATE_FILE" ] && [ "$(cat "$STATE_FILE")" = "on" ]; then
  setprop "$PROP_NAME" 1
else
  setprop "$PROP_NAME" 0
fi

exit 0